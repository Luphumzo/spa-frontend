// require('./bootstrap');

require('../../frontend/src/main.js')
